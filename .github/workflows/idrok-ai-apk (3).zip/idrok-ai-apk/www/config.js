// Server manzilini shu yerga yozing (yoki ilovaning Sozlama bo‘limida kiriting)
window.IDROK_API = '';
